#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
This lambda sends a bag for ingest to test the ingest and storage service is working
"""
import os
import boto3
import json
import logging
import daiquiri
from base64 import b64decode
from wellcome_aws_utils.lambda_utils import log_on_error
from wellcome_storage_client import WellcomeStorageClient


class Config:
    def __init__(self):
        try:
            self.bag_paths      = [b.strip() for b in os.environ["BAG_PATHS"].split(",")]
            self.storage_space  = os.environ["STORAGE_SPACE"]
            self.api_url        = os.environ["API_URL"]
            self.ingests_bucket = os.environ["INGESTS_BUCKET"]
            oauth_details_enc   = os.environ["OAUTH_DETAILS_ENC"]
        except KeyError as key_error:
            raise RuntimeError(f"Environment variable {key_error.args[0]!r} not defined")

        self.oauth_details = None
        if oauth_details_enc:
            try:
                plain_text = self.decrypt(oauth_details_enc)
                self.oauth_details = json.loads(plain_text)
            except:
                raise RuntimeError("oauth_details could not be decrypted/parsed")


    def decrypt(self, cipher_text):
        decrypted = boto3.client('kms').decrypt(CiphertextBlob=b64decode(cipher_text))['Plaintext']
        return decrypted.decode("utf-8")


cfg = Config()
daiquiri.setup(level=os.environ.get("LOG_LEVEL", "INFO"))


@log_on_error
def main(event, context):
    logger = daiquiri.getLogger(__name__)
    logger.info("received trigger event")
    client = WellcomeStorageClient(cfg.api_url, cfg.oauth_details)

    for bag_path in cfg.bag_paths:
        ingest_location = client.ingest(bag_path, cfg.ingests_bucket, cfg.storage_space)
        logger.info(f"triggered ingest for {cfg.bag_paths!r} location: {ingest_location!r}")
