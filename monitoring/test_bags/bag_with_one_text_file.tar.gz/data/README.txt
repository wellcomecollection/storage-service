This is a bag for testing the Wellcome storage service.
